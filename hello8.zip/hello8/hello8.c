#include <stdio.h>
#include <stdlib.h>
#include "hello8.h"

int main(int argc, char *argv[]) {

    printf("%s", getMsg8()); 

    return EXIT_SUCCESS;
}
