// Hello World header file

char *getMsg8(){
    static char msg[] = "Hello world 8!\n";
    return msg;
}
